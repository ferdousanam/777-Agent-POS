<?php
 return [
"brands" => "ब्रांड",
"manage_your_brands" => "अपने ब्रांडों को प्रबंधित करें",
"all_your_brands" => "आपके सभी ब्रांड",
"note" => "ध्यान दें",
"brand_name" => "ब्रांड का नाम",
"short_description" => "संक्षिप्त वर्णन",
"added_success" => "ब्रांड सफलतापूर्वक जोड़ा",
"updated_success" => "ब्रांड सफलतापूर्वक अपडेट किया गया",
"deleted_success" => "ब्रांड सफलतापूर्वक हटा दिया गया",
"add_brand" => "ब्रांड जोड़ें",
"edit_brand" => "ब्रांड संपादित करें",
];
