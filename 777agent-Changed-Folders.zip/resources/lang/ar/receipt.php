<?php
 return [
"product" => "المنتج",
"qty" => "الكمية",
"unit_price" => "سعر الوحدة",
"subtotal" => " المجموع الفرعي",
"discount" => "الخصم",
"tax" => "الضريبة",
"total" => "المجموع",
"invoice_number" => "الفاتورة رقم.",
"date" => "التاريخ",
"receipt_settings" => "إعدادات الاستلام",
"receipt_settings_mgs" => "جميع الإعدادات المتعلقة بإيصال هذا الموقع",
"print_receipt_on_invoice" => "الطباعة التلقائية للفاتورة بعد الانتهاء",
"receipt_printer_type" => "نوع طابعة الاستلام",
"receipt_settings_updated" => "تم تحديث إعدادات الاستلام",
];
