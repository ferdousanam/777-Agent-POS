<?php
 return [
"stock_adjustment" => "Ajustement des stocks",
"stock_adjustments" => "Ajustements des stocks",
"list" => "Liste des ajustements de stock",
"add" => "Ajouter un ajustement de stock",
"all_stock_adjustments" => "Tous les ajustements de stock",
"search_product" => "Rechercher des produits",
"adjustment_type" => "Type d'ajustement",
"normal" => "Ordinaire",
"abnormal" => "Anormal",
"total_amount" => "Montant total",
"total_amount_recovered" => "Montant total récupéré",
"reason_for_stock_adjustment" => "Raison",
"stock_adjustment_added_successfully" => "Ajustement de stock ajouté avec succès",
"search_products" => "Recherche des produits",
"delete_success" => "Ajustement de stock supprimé avec succès",
"view_details" => "Afficher les détails de l'ajustement des stocks",
];
