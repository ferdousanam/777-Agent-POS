<?php
 return [
"tax_rates" => "Tasas de impuestos", /* modified */
"manage_your_tax_rates" => "Administre sus tasas impositivas",
"all_your_tax_rates" => "Todas sus tasas impositivas",
"name" => "Nombre",
"rate" => "Tasa de impuesto %",
"added_success" => "Tasa impositiva agregada con éxito",
"updated_success" => "Tasa de impuestos actualizada con éxito",
"deleted_success" => "Tasa de impuestos eliminada con éxito",
"add_tax_rate" => "Agregar tasa impositiva",
"edit_taxt_rate" => "Editar tasa impositiva",
"add_tax_group" => "Agregar grupo de impuestos",
"tax_group_added_success" => "Grupo de impuestos agregado con éxito",
"tax_group_updated_success" => "Grupo de impuestos actualizado con éxito",
"tax_groups" => "Grupos de impuestos",
"edit_tax_group" => "Editar grupo de impuestos",
"sub_taxes" => "Sub impuestos",
"can_not_be_deleted" => "Esta tasa de impuestos pertenece a algunos grupos de impuestos",
];
