<?php
 return [
"units" => "Njësitë",
"manage_your_units" => "Menaxhoni njësitë tuaja",
"all_your_units" => "Të gjitha njësitë tuaja",
"name" => "Emri",
"short_name" => "Emer i shkurter",
"allow_decimal" => "Lejo decimal",
"added_success" => "Njësia u shtua me sukses",
"updated_success" => "Njësia u përditësua me sukses",
"deleted_success" => "Njësia fshihet me sukses",
"add_unit" => "Shto njësi",
"edit_unit" => "Edit Njësia",
];
